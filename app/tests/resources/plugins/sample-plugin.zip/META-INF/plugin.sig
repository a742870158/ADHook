{"schema":1,"algorithm":"ECDSA_P256_SHA256","keyId":"a4d572957cbfe5324b4c8aaece0b878e","signature":"MEYCIQCYpugqDM+rt0KWnfWwjZ5njqEpqclEZ/krOxq9kQy8FgIhAJG47rgod+Q61KI/7Hs3/2NJxCRek09/id7jhZYdm/bu"}
